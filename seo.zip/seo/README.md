* pages -> title
* pages -> headers
* meta keywords
* meta description
* pages -> issues -> errors -> unused-css-rules
* pages -> issues -> errors -> unused-javascript-rules
* pages -> issues -> errors -> uses-optimized-images
* pages -> issues -> errors -> geolocation-on-start
* pages -> issues -> errors -> doctype
* pages -> issues -> errors -> errors-in-console
* pages -> issues -> errors ->

## Docoument

* baki feature mushkil hn budget 50+

### API google

* https://web.dev/performance-scoring/?utm_source=lighthouse&utm_medium=unknown

  "geolocation-on-start": {
  "id": "geolocation-on-start",
  "title": "Avoids requesting the geolocation permission on page load",
  "description": "Users are mistrustful of or confused by sites that request their location without context. Consider tying the request to a user action instead. [Learn more](https://web.dev/geolocation-on-start/).",
  "score": 1,
  "scoreDisplayMode": "binary",
  "details": {
  "type": "table",
  "headings": [],
  "items": []
  }
  },

  "notification-on-start": {
  "id": "notification-on-start",
  "title": "Avoids requesting the notification permission on page load",
  "description": "Users are mistrustful of or confused by sites that request to send notifications without context. Consider tying the request to user gestures instead. [Learn more](https://web.dev/notification-on-start/).",
  "score": 1,
  "scoreDisplayMode": "binary",
  "details": {
  "type": "table",
  "headings": [],
  "items": []
  }
  },

  "robots-txt": {
  "id": "robots-txt",
  "title": "robots.txt is valid",
  "description": "If your robots.txt file is malformed, crawlers may not be able to understand how you want your website to be crawled or indexed. [Learn more](https://web.dev/robots-txt/).",
  "score": 1,
  "scoreDisplayMode": "binary",
  "details": {
  "type": "table",
  "headings": [],
  "items": [],
  "summary": {}
  }
  },

  "seo": {
  "title": "SEO",
  "description": "These checks ensure that your page is optimized for search engine results ranking. There are additional factors Lighthouse does not check that may affect your search ranking. [Learn more](https://support.google.com/webmasters/answer/35769).",
  "manualDescription": "Run these additional validators on your site to check additional SEO best practices.",
  "auditRefs": [
  {
  "id": "viewport",
  "weight": 1,
  "group": "seo-mobile"
  },
  {
  "id": "document-title",
  "weight": 1,
  "group": "seo-content"
  },
  {
  "id": "meta-description",
  "weight": 1,
  "group": "seo-content"
  },
  {
  "id": "http-status-code",
  "weight": 1,
  "group": "seo-crawl"
  },
  {
  "id": "link-text",
  "weight": 1,
  "group": "seo-content"
  },
  {
  "id": "crawlable-anchors",
  "weight": 1,
  "group": "seo-crawl"
  },
  {
  "id": "is-crawlable",
  "weight": 1,
  "group": "seo-crawl"
  },
  {
  "id": "robots-txt",
  "weight": 1,
  "group": "seo-crawl"
  },
  {
  "id": "image-alt",
  "weight": 1,
  "group": "seo-content"
  },
  {
  "id": "hreflang",
  "weight": 1,
  "group": "seo-content"
  },
  {
  "id": "canonical",
  "weight": 1,
  "group": "seo-content"
  },
  {
  "id": "font-size",
  "weight": 1,
  "group": "seo-mobile"
  },
  {
  "id": "plugins",
  "weight": 1,
  "group": "seo-content"
  },
  {
  "id": "tap-targets",
  "weight": 1,
  "group": "seo-mobile"
  },
  {
  "id": "structured-data",
  "weight": 0
  }
  ],
  "id": "seo",
  "score": 0.86
  },
* Node js and Angular isnatall
* npm install or npm i
* node server and npm start
*
