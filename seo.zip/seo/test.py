import requests
from concurrent.futures import ThreadPoolExecutor
import time


list_of_urls = list(range(0 , 100))

def get_url(url):
    result = (requests.post('http://78.47.67.72/api/mp3', json={"url": "http://195.201.5.100/9407cdd76468673bbfc862a6a1613199.mp3"} , timeout=0.01))
    return result

def millis():
      return int(round(time.time() * 1000))
with ThreadPoolExecutor(max_workers=50) as pool:
    start_time = millis()
    temp = list(pool.map(get_url,list_of_urls))
    print ("\nTotal took " + str(millis() - start_time) + " ms\n" ,temp )